Kaggle username: kevinlwong


Final Kaggle leaderboard score: 0.82244

Leaderboard Placement: 1st Place as of 8/5/2024 10:36 PM